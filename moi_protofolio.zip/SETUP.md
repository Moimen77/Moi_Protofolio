# 🎉 Welcome to moi_protofolio!

This project was generated dynamically based on your specific requirements. Before running your app for the first time, follow this brief setup guide to configure the required environment variables, permissions, and dependencies locally.

---

## 1. 📦 Initial Dependencies & Generation

First, fetch all pub packages:
```bash
flutter pub get
```

### Code Generation
*(No initial code generation required for your main stack)*

### Localization
Since you chose to include `easy_localization`, run these commands whenever you add or modify string translations to generate your keys correctly:
```bash
flutter pub run easy_localization:generate -S assets/translations -O lib/src/core/i18n -o locale_keys.g.dart
```

---

## 2. 🎨 Native Splash Screen Setup

This project uses `flutter_native_splash`.

**To apply your custom app launch screen:**
1. Place your transparent splash logo at [`assets/images/splash.png`](assets/images/splash.png).
2. Open [`flutter_native_splash.yaml`](flutter_native_splash.yaml) in the root of your project.
3. Uncomment the `image:` paths so it looks like:
   ```yaml
   flutter_native_splash:
     color: "##09081c"
     image: assets/images/splash.png
     android_12:
       image: assets/images/splash.png
       icon_background_color: "##09081c"
   ```
4. Apply the native configuration natively by running:
```bash
dart run flutter_native_splash:create --path=flutter_native_splash.yaml
```
*Note: Run this command every time you change your splash image or background color.*

---

## 3. 🔐 App Permissions (Android & iOS)

Based on your chosen flags (e.g.   ), you must configure Native permissions before testing these features.

### Android Setup
Open [`android/app/src/main/AndroidManifest.xml`](android/app/src/main/AndroidManifest.xml) and add the following required permissions inside the `<manifest>` tag, directly above the `<application>` block:

```xml
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <!-- Internet is standard and required -->
    <uses-permission android:name="android.permission.INTERNET" />
    
```

### iOS Setup 
First, describe why you need permissions. Open [`ios/Runner/Info.plist`](ios/Runner/Info.plist) and add the following inside the main `<dict>` block:

```xml
<dict>
    ...
</dict>
```


---

## 4. 🌍 Environment Variables

Your project relies on `flutter_dotenv` to load secrets. 

1. Create a [`.env`](.env) file in the project root folder.
2. Insert your required variables (e.g. `API_URL=https://api.example.com`).
3. These keys are now accessible in Dart via `dotenv.env['API_URL']`.

---

## 5. 💾 Local Storage (Hive)

*(No local storage (Hive) selected for this project)*

---

## 6. ☁️ Backend Connections

*(No remote backend provider selected. The application defaults to managing state via Mock services locally).*

---

## 7. 🚀 Running the App

Once everything above is verified:

1. **For iOS Simulators/Devices**, map your native pods locally:
```bash
cd ios
pod install
cd ..
```

2. Run your app via VS Code, Android Studio, or CLI:
```bash
flutter run
```

Congratulations, and happy coding!
