import 'package:get/get.dart';
import 'package:moi_protofolio/src/services/auth_repository_impl.dart';

import 'package:moi_protofolio/src/controllers/auth/auth_controller.dart';

class AppBindings implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(
      () => AuthController(repository: AuthRepositoryImpl()),
    );
  }
}
