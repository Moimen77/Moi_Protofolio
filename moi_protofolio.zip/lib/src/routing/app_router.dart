import 'package:moi_protofolio/src/imports/imports.dart';
import 'package:moi_protofolio/src/routing/app_routes.dart';

import 'package:moi_protofolio/src/views/auth/login_screen.dart';
import 'package:moi_protofolio/src/views/auth/signup_screen.dart';
import 'package:moi_protofolio/src/views/auth/forgot_password_screen.dart';

import 'package:moi_protofolio/src/views/home/home_page.dart';
import 'package:moi_protofolio/src/views/onboarding/onboarding_page.dart';


class AppRouter {
  static List<GetPage> get getPages => [
    GetPage(
      name: AppRoutes.onboarding,
      page: () => const OnboardingPage(),
    ),
    GetPage(
      name: AppRoutes.login,
      page: () => const LoginScreen(),
    ),
    GetPage(
      name: AppRoutes.signup,
      page: () => const SignupScreen(),
    ),
    GetPage(
      name: AppRoutes.forgotPassword,
      page: () => const ForgotPasswordScreen(),
    ),
    GetPage(
      name: AppRoutes.home,
      page: () => const HomePage(),
    ),
  ];
}
